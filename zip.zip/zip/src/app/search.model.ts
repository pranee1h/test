export interface ISearch {
    topic: string;
    user: string;
}