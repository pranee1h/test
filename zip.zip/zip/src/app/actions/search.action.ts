import { Action } from '@ngrx/store';
import { ISearch } from '../search.model';

export enum SearchActionTypes {
    addSearch = '[Search] AddSearch',
};

export class AddSearch implements Action {
    readonly type = SearchActionTypes.addSearch;

    constructor(public payload: ISearch) { }
}

export type SearchActions
                        = AddSearch;
