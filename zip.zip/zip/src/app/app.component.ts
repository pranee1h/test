import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { AddSearch } from './actions/search.action';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'InterviewApp';

  constructor(private store: Store<any>) {
  }

  ngOnInit() {
    this.store.dispatch(new AddSearch({
      topic: 'test',
      user: 'fahk'
    }))
    this.store.subscribe((data) => {
      console.log(data.search);
    })
  }
}
