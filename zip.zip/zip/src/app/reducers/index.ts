import {
    ActionReducer,
    ActionReducerMap,
    createFeatureSelector,
    createSelector,
    MetaReducer
  } from '@ngrx/store';
  import { environment } from '../../environments/environment';
import { ISearch } from '../search.model';
import { reducer } from './search.reducer';
  
  export interface State {
    search: ISearch
  }
  
  export const reducers: ActionReducerMap<State> = {
    search: reducer
  };
  
  
  export const metaReducers: MetaReducer<State>[] = !environment.production ? [] : [];
  