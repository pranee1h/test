import * as search from "../actions/search.action";
import { SearchActionTypes } from "../actions/search.action";

export interface State {
    topic: string;
    user: string;
};

const initialState: State = {
    topic: '',
    user: ''
};

export function reducer(state = initialState, action: search.SearchActions): State {
    switch (action.type) {

        case SearchActionTypes.addSearch: {
            return action.payload;
        }

        default: {
            return state;
        }
    }
}